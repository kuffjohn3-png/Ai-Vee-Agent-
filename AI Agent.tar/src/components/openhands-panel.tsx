'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Bot, 
  Play, 
  Code, 
  Search, 
  Settings, 
  CheckCircle, 
  XCircle, 
  Clock,
  Zap
} from 'lucide-react'
import { useOpenHandsStore } from '@/stores/openhands-store'
import { OpenHandsTask } from '@/lib/openhands/types'

export default function OpenHandsPanel() {
  const { 
    agents, 
    currentAgent, 
    tasks, 
    isExecutingTask, 
    executeTask,
    clearTasks 
  } = useOpenHandsStore()

  const [selectedTaskType, setSelectedTaskType] = useState<OpenHandsTask['type']>('code_execution')

  const handleQuickTask = async (type: OpenHandsTask['type'], prompt?: string) => {
    if (!currentAgent) return

    try {
      await executeTask({
        type,
        prompt: prompt || `Quick ${type} task`,
        code: prompt ? undefined : '// Sample code for ' + type
      })
    } catch (error) {
      console.error('Task execution failed:', error)
    }
  }

  const getStatusIcon = (status: OpenHandsTask['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />
      case 'running':
        return <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      default:
        return <Clock className="w-4 h-4 text-gray-500" />
    }
  }

  const getStatusColor = (status: OpenHandsTask['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-50 text-green-700 border-green-200'
      case 'failed':
        return 'bg-red-50 text-red-700 border-red-200'
      case 'running':
        return 'bg-blue-50 text-blue-700 border-blue-200'
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200'
    }
  }

  return (
    <div className="space-y-4">
      {/* Agent Status */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Bot className="w-5 h-5" />
            AI Agent Status
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {currentAgent && (
            <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div>
                <div className="font-medium">{currentAgent.name}</div>
                <div className="text-sm text-muted-foreground">
                  Environment: {currentAgent.environment}
                </div>
              </div>
              <Badge variant={currentAgent.status === 'idle' ? 'secondary' : 'default'}>
                {currentAgent.status}
              </Badge>
            </div>
          )}
          
          <div className="flex flex-wrap gap-2">
            {currentAgent?.capabilities.map((capability) => (
              <Badge key={capability} variant="outline" className="text-xs">
                {capability.replace('_', ' ')}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickTask('code_analysis')}
              disabled={isExecutingTask}
              className="justify-start"
            >
              <Search className="w-4 h-4 mr-2" />
              Analyze Code
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickTask('code_generation')}
              disabled={isExecutingTask}
              className="justify-start"
            >
              <Code className="w-4 h-4 mr-2" />
              Generate Code
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickTask('debugging')}
              disabled={isExecutingTask}
              className="justify-start"
            >
              <Search className="w-4 h-4 mr-2" />
              Debug Issue
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleQuickTask('refactoring')}
              disabled={isExecutingTask}
              className="justify-start"
            >
              <Settings className="w-4 h-4 mr-2" />
              Refactor Code
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Task History */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Task History
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={clearTasks}
            disabled={tasks.length === 0}
          >
            Clear
          </Button>
        </CardHeader>
        <CardContent>
          {tasks.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Bot className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No tasks executed yet</p>
              <p className="text-sm">Try one of the quick actions above</p>
            </div>
          ) : (
            <ScrollArea className="h-64">
              <div className="space-y-2">
                {tasks.map((task) => (
                  <div
                    key={task.id}
                    className={`p-3 rounded-lg border ${getStatusColor(task.status)}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          {getStatusIcon(task.status)}
                          <span className="font-medium text-sm truncate">
                            {task.type.replace('_', ' ')}
                          </span>
                        </div>
                        <p className="text-xs opacity-75 line-clamp-2">
                          {task.prompt}
                        </p>
                        <div className="text-xs opacity-60 mt-1">
                          {task.createdAt.toLocaleTimeString()}
                        </div>
                      </div>
                      {task.language && (
                        <Badge variant="outline" className="text-xs ml-2">
                          {task.language}
                        </Badge>
                      )}
                    </div>
                    
                    {task.error && (
                      <div className="mt-2 text-xs text-red-600 bg-red-50 p-2 rounded">
                        Error: {task.error}
                      </div>
                    )}
                    
                    {task.result && task.status === 'completed' && (
                      <div className="mt-2 text-xs text-green-600 bg-green-50 p-2 rounded">
                        Task completed successfully
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  )
}