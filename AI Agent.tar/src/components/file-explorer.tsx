'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { 
  File, 
  Folder, 
  Plus, 
  Trash2, 
  Edit3, 
  Check, 
  X,
  FileText,
  FileCode,
  FileJson,
  FilePlus,
  Sparkles
} from 'lucide-react'
import { useCodeStore } from '@/stores/code-store'
import { codeTemplates, getCategories } from '@/lib/templates'

const getFileIcon = (fileName: string) => {
  const ext = fileName.split('.').pop()?.toLowerCase()
  
  switch (ext) {
    case 'js':
    case 'jsx':
    case 'ts':
    case 'tsx':
    case 'py':
    case 'java':
    case 'cpp':
    case 'c':
      return FileCode
    case 'json':
      return FileJson
    case 'md':
    case 'txt':
      return FileText
    default:
      return File
  }
}

export default function FileExplorer() {
  const { files, currentFile, createFile, deleteFile, setCurrentFile, renameFile } = useCodeStore()
  const [newFileName, setNewFileName] = useState('')
  const [showNewFileInput, setShowNewFileInput] = useState(false)
  const [editingFileId, setEditingFileId] = useState<string | null>(null)
  const [editingFileName, setEditingFileName] = useState('')

  const handleCreateFile = () => {
    if (newFileName.trim()) {
      createFile(newFileName.trim())
      setNewFileName('')
      setShowNewFileInput(false)
    }
  }

  const handleCreateFromTemplate = (template: typeof codeTemplates[0]) => {
    const fileName = `${template.name.toLowerCase().replace(/\s+/g, '-')}.${template.language === 'typescript' ? 'ts' : template.language}`
    createFile(fileName, template.content, template.language)
  }

  const handleDeleteFile = (fileId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (files.length > 1) {
      deleteFile(fileId)
    }
  }

  const handleStartEdit = (fileId: string, fileName: string, e: React.MouseEvent) => {
    e.stopPropagation()
    setEditingFileId(fileId)
    setEditingFileName(fileName)
  }

  const handleSaveEdit = () => {
    if (editingFileName.trim() && editingFileId) {
      renameFile(editingFileId, editingFileName.trim())
      setEditingFileId(null)
      setEditingFileName('')
    }
  }

  const handleCancelEdit = () => {
    setEditingFileId(null)
    setEditingFileName('')
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-3 border-b">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowNewFileInput(true)}
          className="w-full justify-start"
        >
          <Plus className="w-4 h-4 mr-2" />
          New File
        </Button>
      </div>

      {/* New File Input */}
      {showNewFileInput && (
        <div className="p-3 border-b">
          <div className="flex gap-2">
            <Input
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              placeholder="filename.js"
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleCreateFile()
                if (e.key === 'Escape') {
                  setShowNewFileInput(false)
                  setNewFileName('')
                }
              }}
              className="flex-1"
              autoFocus
            />
            <Button size="sm" onClick={handleCreateFile}>
              <Check className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setShowNewFileInput(false)
                setNewFileName('')
              }}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Templates Section */}
      <div className="border-b">
        <div className="p-3">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium">Templates</span>
          </div>
          <ScrollArea className="h-32">
            <div className="space-y-1">
              {codeTemplates.map((template) => (
                <Button
                  key={template.id}
                  variant="ghost"
                  size="sm"
                  onClick={() => handleCreateFromTemplate(template)}
                  className="w-full justify-start h-auto p-2"
                >
                  <div className="text-left">
                    <div className="text-xs font-medium">{template.name}</div>
                    <div className="text-xs text-muted-foreground">{template.language}</div>
                  </div>
                </Button>
              ))}
            </div>
          </ScrollArea>
        </div>
      </div>

      {/* Files List */}
      <div className="flex-1 flex flex-col">
        <div className="p-3 border-b">
          <div className="flex items-center gap-2">
            <File className="w-4 h-4" />
            <span className="text-sm font-medium">Files</span>
            <Badge variant="secondary" className="ml-auto text-xs">
              {files.length}
            </Badge>
          </div>
        </div>
        
        <ScrollArea className="flex-1">
          <div className="p-2">
            {files.map((file) => {
              const FileIcon = getFileIcon(file.name)
              const isEditing = editingFileId === file.id
              const isActive = currentFile?.id === file.id

              return (
                <div
                  key={file.id}
                  className={`group flex items-center gap-2 p-2 rounded-md cursor-pointer transition-colors ${
                    isActive ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                  }`}
                  onClick={() => !isEditing && setCurrentFile(file)}
                >
                  <FileIcon className="w-4 h-4 flex-shrink-0" />
                  
                  {isEditing ? (
                    <div className="flex-1 flex gap-1">
                      <Input
                        value={editingFileName}
                        onChange={(e) => setEditingFileName(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSaveEdit()
                          if (e.key === 'Escape') handleCancelEdit()
                        }}
                        className="flex-1 h-7 text-sm"
                        autoFocus
                        onClick={(e) => e.stopPropagation()}
                      />
                      <Button
                        size="sm"
                        className="h-7 w-7 p-0"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleSaveEdit()
                        }}
                      >
                        <Check className="w-3 h-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 w-7 p-0"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleCancelEdit()
                        }}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <span className="flex-1 text-sm truncate">{file.name}</span>
                      <div className="opacity-0 group-hover:opacity-100 flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0"
                          onClick={(e) => handleStartEdit(file.id, file.name, e)}
                        >
                          <Edit3 className="w-3 h-3" />
                        </Button>
                        {files.length > 1 && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0 hover:text-destructive"
                            onClick={(e) => handleDeleteFile(file.id, e)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </>
                  )}
                </div>
              )
            })}
          </div>
        </ScrollArea>
      </div>
    </div>
  )
}