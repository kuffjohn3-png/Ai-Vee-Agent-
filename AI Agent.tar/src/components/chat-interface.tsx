'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Send, 
  Sparkles, 
  Code2, 
  Bug, 
  BookOpen, 
  Zap,
  User,
  Bot,
  Play,
  Search
} from 'lucide-react'
import { useChatStore } from '@/stores/chat-store'
import { useCodeStore } from '@/stores/code-store'
import { useOpenHandsStore } from '@/stores/openhands-store'

const quickActions = [
  { icon: Code2, label: 'Generate Code', prompt: 'Generate a React component for a todo list' },
  { icon: Bug, label: 'Debug Code', prompt: 'Help me debug this code:' },
  { icon: BookOpen, label: 'Explain Concept', prompt: 'Explain how closures work in JavaScript' },
  { icon: Zap, label: 'Optimize', prompt: 'Optimize this code for better performance:' },
  { icon: Play, label: 'Execute Code', prompt: 'Execute this code with OpenHands sandbox:' },
  { icon: Search, label: 'Analyze Code', prompt: 'Analyze this code for improvements:' }
]

export default function ChatInterface() {
  const [input, setInput] = useState('')
  const { messages, isLoading, sendMessage } = useChatStore()
  const { currentFile } = useCodeStore()
  const { executeTask } = useOpenHandsStore()
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const messageToSend = input.trim()
    setInput('')
    
    await sendMessage(messageToSend)
  }

  const handleQuickAction = async (prompt: string) => {
    if (currentFile && prompt.includes('this code')) {
      prompt += `\n\n\`\`\`${currentFile.language}\n${currentFile.content}\n\`\`\``
    }
    
    // Check if this is an OpenHands-specific action
    if (prompt.includes('OpenHands sandbox')) {
      if (currentFile) {
        try {
          await executeTask({
            type: 'code_execution',
            code: currentFile.content,
            language: currentFile.language
          })
          setInput('Code executed in OpenHands sandbox. Check the OpenHands tab for results.')
        } catch (error) {
          setInput('Failed to execute code. Please try again.')
        }
      }
      return
    }
    
    if (prompt.includes('Analyze this code')) {
      if (currentFile) {
        try {
          await executeTask({
            type: 'code_analysis',
            code: currentFile.content,
            language: currentFile.language
          })
          setInput('Code analyzed with OpenHands. Check the OpenHands tab for results.')
        } catch (error) {
          setInput('Failed to analyze code. Please try again.')
        }
      }
      return
    }
    
    setInput(prompt)
  }

  const formatMessage = (content: string) => {
    // Simple markdown-like formatting for code blocks
    return content.split('```').map((part, index) => {
      if (index % 2 === 1) {
        // This is a code block
        const lines = part.split('\n')
        const language = lines[0] || 'text'
        const code = lines.slice(1).join('\n')
        
        return (
          <div key={index} className="my-4">
            <div className="bg-muted px-3 py-1 rounded-t-md text-sm font-mono">
              {language}
            </div>
            <pre className="bg-muted/50 p-3 rounded-b-md overflow-x-auto text-sm">
              <code>{code}</code>
            </pre>
          </div>
        )
      }
      
      // Regular text - handle line breaks
      return part.split('\n').map((line, lineIndex) => (
        <p key={`${index}-${lineIndex}`} className="mb-2 last:mb-0">
          {line}
        </p>
      ))
    })
  }

  return (
    <div className="h-full flex flex-col">
      {/* Chat Header */}
      <div className="p-4 border-b">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          <h3 className="font-semibold">AI Coding Assistant</h3>
          <Badge variant="outline" className="ml-auto">
            {messages.length} messages
          </Badge>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="p-4 border-b">
        <div className="grid grid-cols-2 gap-2">
          {quickActions.map((action) => (
            <Button
              key={action.label}
              variant="outline"
              size="sm"
              onClick={() => handleQuickAction(action.prompt)}
              className="justify-start h-auto p-3"
            >
              <action.icon className="w-4 h-4 mr-2 flex-shrink-0" />
              <span className="text-xs">{action.label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${
                message.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {message.role === 'assistant' && (
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-primary" />
                </div>
              )}
              
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.role === 'user'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                }`}
              >
                <div className="text-sm">
                  {formatMessage(message.content)}
                </div>
                <div className="text-xs opacity-70 mt-2">
                  {message.timestamp.toLocaleTimeString()}
                </div>
              </div>

              {message.role === 'user' && (
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-primary-foreground" />
                </div>
              )}
            </div>
          ))}
          
          {isLoading && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Bot className="w-4 h-4 text-primary" />
              </div>
              <div className="bg-muted rounded-lg p-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-100" />
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-200" />
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="p-4 border-t">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask me anything about coding..."
            className="flex-1 min-h-[60px] max-h-[120px] resize-none"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                handleSubmit(e)
              }
            }}
          />
          <Button 
            type="submit" 
            disabled={!input.trim() || isLoading}
            className="self-end"
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
        <div className="text-xs text-muted-foreground mt-2 text-center">
          Press Enter to send, Shift+Enter for new line
        </div>
      </div>
    </div>
  )
}