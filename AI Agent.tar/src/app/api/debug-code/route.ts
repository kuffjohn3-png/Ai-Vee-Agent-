import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { code, issue } = await request.json()

    if (!code || !issue) {
      return NextResponse.json(
        { error: 'Code and issue are required' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert debugging assistant. Analyze the code and issue, then provide specific fixes and explanations.'
        },
        {
          role: 'user',
          content: `Code:\n\`\`\`javascript\n${code}\n\`\`\`\n\nIssue: ${issue}\n\nPlease identify the problem and provide a solution.`
        }
      ],
      temperature: 0.3,
      max_tokens: 2000
    })

    const analysis = completion.choices[0]?.message?.content

    if (!analysis) {
      throw new Error('No analysis generated')
    }

    return NextResponse.json({
      success: true,
      analysis,
      type: 'debugging'
    })

  } catch (error) {
    console.error('Debug code API error:', error)
    return NextResponse.json(
      { error: 'Failed to debug code' },
      { status: 500 }
    )
  }
}