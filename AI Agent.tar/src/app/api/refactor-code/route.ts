import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { code, instructions } = await request.json()

    if (!code || !instructions) {
      return NextResponse.json(
        { error: 'Code and instructions are required' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert code refactoring assistant. Improve code quality, performance, and maintainability based on the given instructions.'
        },
        {
          role: 'user',
          content: `Code:\n\`\`\`javascript\n${code}\n\`\`\`\n\nRefactoring instructions: ${instructions}\n\nProvide improved code with explanations.`
        }
      ],
      temperature: 0.5,
      max_tokens: 2000
    })

    const refactoredCode = completion.choices[0]?.message?.content

    if (!refactoredCode) {
      throw new Error('No refactoring generated')
    }

    return NextResponse.json({
      success: true,
      refactoredCode,
      type: 'refactoring'
    })

  } catch (error) {
    console.error('Refactor code API error:', error)
    return NextResponse.json(
      { error: 'Failed to refactor code' },
      { status: 500 }
    )
  }
}