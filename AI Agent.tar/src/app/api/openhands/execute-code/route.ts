import { NextRequest, NextResponse } from 'next/server'
import { exec } from 'child_process'
import { promisify } from 'util'
import fs from 'fs/promises'
import path from 'path'
import { v4 as uuidv4 } from 'uuid'

const execAsync = promisify(exec)

const languageConfigs = {
  javascript: {
    extension: 'js',
    command: 'node',
    timeout: 5000,
    setup: 'console.log("=== Execution Start ===");'
  },
  python: {
    extension: 'py',
    command: 'python3',
    timeout: 5000,
    setup: 'print("=== Execution Start ===")'
  },
  typescript: {
    extension: 'ts',
    command: 'npx ts-node',
    timeout: 5000,
    setup: 'console.log("=== Execution Start ===");'
  },
  java: {
    extension: 'java',
    command: 'java',
    timeout: 10000,
    setup: 'System.out.println("=== Execution Start ===");'
  }
}

interface SandboxEnvironment {
  id: string
  workingDirectory: string
  resources: {
    memory: string
    cpu: string
    diskSpace: string
  }
  permissions: string[]
  networkAccess: boolean
}

export async function POST(request: NextRequest) {
  try {
    const { code, language = 'javascript', sandbox = true } = await request.json()

    if (!code) {
      return NextResponse.json(
        { error: 'Code is required' },
        { status: 400 }
      )
    }

    const config = languageConfigs[language as keyof typeof languageConfigs]
    if (!config) {
      return NextResponse.json(
        { error: `Unsupported language: ${language}` },
        { status: 400 }
      )
    }

    // Create sandbox environment
    const sandboxEnv = await createSandboxEnvironment(sandbox)
    
    try {
      // Execute code in sandbox
      const result = await executeInSandbox(code, language, config, sandboxEnv)
      
      // Cleanup sandbox
      await cleanupSandbox(sandboxEnv)
      
      return NextResponse.json({
        success: true,
        output: result.stdout,
        error: result.stderr,
        language,
        executionTime: result.executionTime,
        sandbox: {
          id: sandboxEnv.id,
          memoryUsed: sandboxEnv.resources.memory,
          executionTime: result.executionTime
        }
      })

    } catch (error: any) {
      // Cleanup sandbox on error
      await cleanupSandbox(sandboxEnv).catch(() => {})
      
      if (error.killed && error.signal === 'SIGTERM') {
        return NextResponse.json({
          success: false,
          error: 'Code execution timed out',
          timeout: config.timeout,
          language,
          sandbox: {
            id: sandboxEnv.id,
            status: 'timeout'
          }
        })
      }

      return NextResponse.json({
        success: false,
        error: error.stderr || error.message || 'Execution failed',
        language,
        sandbox: {
          id: sandboxEnv.id,
          status: 'error'
        }
      })
    }

  } catch (error) {
    console.error('OpenHands code execution API error:', error)
    return NextResponse.json(
      { error: 'Failed to execute code' },
      { status: 500 }
    )
  }
}

async function createSandboxEnvironment(enabled: boolean): Promise<SandboxEnvironment> {
  const sandboxId = uuidv4()
  const workingDirectory = `/tmp/openhands_sandbox_${sandboxId}`
  
  // Create sandbox directory
  await fs.mkdir(workingDirectory, { recursive: true })
  
  const sandboxEnv: SandboxEnvironment = {
    id: sandboxId,
    workingDirectory,
    resources: {
      memory: '512MB',
      cpu: '1',
      diskSpace: '100MB'
    },
    permissions: ['read', 'write', 'execute'],
    networkAccess: false
  }
  
  // Log sandbox creation
  console.log(`OpenHands sandbox created: ${sandboxId} at ${workingDirectory}`)
  
  return sandboxEnv
}

async function executeInSandbox(
  code: string, 
  language: string, 
  config: any, 
  sandbox: SandboxEnvironment
): Promise<any> {
  const fileName = `execute.${config.extension}`
  const filePath = path.join(sandbox.workingDirectory, fileName)
  
  // Prepare code with setup
  const fullCode = `${config.setup}\n${code}`
  
  // Write code to sandbox
  await fs.writeFile(filePath, fullCode, 'utf8')
  
  const startTime = Date.now()
  
  // Execute with resource limits
  const { stdout, stderr } = await execAsync(
    `cd ${sandbox.workingDirectory} && ${config.command} ${fileName}`,
    {
      timeout: config.timeout,
      cwd: sandbox.workingDirectory,
      env: {
        ...process.env,
        OPENHANDS_SANDBOX_ID: sandbox.id,
        OPENHANDS_MEMORY_LIMIT: sandbox.resources.memory,
        OPENHANDS_CPU_LIMIT: sandbox.resources.cpu
      }
    }
  )
  
  const executionTime = Date.now() - startTime
  
  return {
    stdout,
    stderr,
    executionTime
  }
}

async function cleanupSandbox(sandbox: SandboxEnvironment): Promise<void> {
  try {
    // Remove sandbox directory
    await fs.rm(sandbox.workingDirectory, { recursive: true, force: true })
    console.log(`OpenHands sandbox cleaned up: ${sandbox.id}`)
  } catch (error) {
    console.error(`Failed to cleanup sandbox ${sandbox.id}:`, error)
  }
}

// GET endpoint for sandbox status
export async function GET() {
  return NextResponse.json({
    status: 'OpenHands sandbox environment ready',
    supportedLanguages: Object.keys(languageConfigs),
    features: {
      sandboxedExecution: true,
      resourceLimits: true,
      timeoutProtection: true,
      networkIsolation: true
    }
  })
}