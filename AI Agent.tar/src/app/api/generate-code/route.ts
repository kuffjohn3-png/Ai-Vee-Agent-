import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { prompt, language = 'javascript' } = await request.json()

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: `You are an expert code generator. Generate clean, efficient, and well-commented code based on the user's requirements. 
          
          Guidelines:
          - Write production-ready code with proper error handling
          - Include helpful comments explaining the logic
          - Follow best practices and coding conventions for ${language}
          - Use modern syntax and features when appropriate
          - Return only the code without explanations unless specifically asked
          - Format the response as a code block with the appropriate language specifier`
        },
        {
          role: 'user',
          content: `Generate ${language} code for: ${prompt}`
        }
      ],
      temperature: 0.3,
      max_tokens: 1500
    })

    const response = completion.choices[0]?.message?.content

    if (!response) {
      throw new Error('No response from AI')
    }

    // Extract code from markdown code blocks if present
    const codeMatch = response.match(/```[\w]*\n?([\s\S]*?)\n?```/)
    const code = codeMatch ? codeMatch[1].trim() : response.trim()

    return NextResponse.json({ 
      code,
      language,
      rawResponse: response 
    })

  } catch (error) {
    console.error('Code generation API error:', error)
    return NextResponse.json(
      { error: 'Failed to generate code' },
      { status: 500 }
    )
  }
}