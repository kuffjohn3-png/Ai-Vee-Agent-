import { NextRequest, NextResponse } from 'next/server'
import { exec } from 'child_process'
import { promisify } from 'util'
import fs from 'fs/promises'
import path from 'path'

const execAsync = promisify(exec)

const languageConfigs = {
  javascript: {
    extension: 'js',
    command: 'node',
    timeout: 5000
  },
  python: {
    extension: 'py',
    command: 'python3',
    timeout: 5000
  },
  typescript: {
    extension: 'ts',
    command: 'npx ts-node',
    timeout: 5000
  }
}

export async function POST(request: NextRequest) {
  try {
    const { code, language = 'javascript' } = await request.json()

    if (!code) {
      return NextResponse.json(
        { error: 'Code is required' },
        { status: 400 }
      )
    }

    const config = languageConfigs[language as keyof typeof languageConfigs]
    if (!config) {
      return NextResponse.json(
        { error: `Unsupported language: ${language}` },
        { status: 400 }
      )
    }

    // Create a temporary file
    const tempDir = '/tmp'
    const fileName = `temp_${Date.now()}.${config.extension}`
    const filePath = path.join(tempDir, fileName)

    try {
      // Write code to temporary file
      await fs.writeFile(filePath, code, 'utf8')

      // Execute the code
      const { stdout, stderr } = await execAsync(`${config.command} ${filePath}`, {
        timeout: config.timeout,
        cwd: tempDir
      })

      // Clean up temporary file
      await fs.unlink(filePath).catch(() => {}) // Ignore cleanup errors

      return NextResponse.json({
        success: true,
        output: stdout,
        error: stderr,
        language
      })

    } catch (error: any) {
      // Clean up temporary file if it exists
      try {
        await fs.unlink(filePath)
      } catch {}

      if (error.killed && error.signal === 'SIGTERM') {
        return NextResponse.json({
          success: false,
          error: 'Code execution timed out (5s limit)',
          language
        })
      }

      return NextResponse.json({
        success: false,
        error: error.stderr || error.message || 'Execution failed',
        language
      })
    }

  } catch (error) {
    console.error('Code execution API error:', error)
    return NextResponse.json(
      { error: 'Failed to execute code' },
      { status: 500 }
    )
  }
}