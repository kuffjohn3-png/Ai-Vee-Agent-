import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { code, language = 'javascript' } = await request.json()

    if (!code) {
      return NextResponse.json(
        { error: 'Code is required' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: `You are an expert code analyzer. Analyze the provided code and give comprehensive feedback including:
          
          - Code quality assessment
          - Potential bugs or issues
          - Performance optimization suggestions
          - Security vulnerabilities
          - Best practices violations
          - Code style and formatting recommendations
          - Complexity analysis
          
          Provide your analysis in a structured format with clear sections. Be constructive and specific in your feedback.`
        },
        {
          role: 'user',
          content: `Analyze this ${language} code:\n\n\`\`\`${language}\n${code}\n\`\`\``
        }
      ],
      temperature: 0.3,
      max_tokens: 2000
    })

    const analysis = completion.choices[0]?.message?.content

    if (!analysis) {
      throw new Error('No analysis from AI')
    }

    return NextResponse.json({ 
      analysis,
      language,
      codeLength: code.length,
      lineCount: code.split('\n').length
    })

  } catch (error) {
    console.error('Code analysis API error:', error)
    return NextResponse.json(
      { error: 'Failed to analyze code' },
      { status: 500 }
    )
  }
}