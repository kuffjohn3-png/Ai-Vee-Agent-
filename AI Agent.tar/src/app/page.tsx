'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Code2, 
  MessageSquare, 
  Play, 
  Save, 
  FolderOpen, 
  Settings,
  Sparkles,
  Zap,
  Bot
} from 'lucide-react'
import CodeEditor from '@/components/code-editor'
import ChatInterface from '@/components/chat-interface'
import FileExplorer from '@/components/file-explorer'
import OpenHandsPanel from '@/components/openhands-panel'
import { useCodeStore } from '@/stores/code-store'
import { useChatStore } from '@/stores/chat-store'

export default function AICodingAgent() {
  const [activeTab, setActiveTab] = useState('editor')
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const { currentFile } = useCodeStore()
  const { messages, isLoading, sendMessage } = useChatStore()

  const handleExecuteCode = async () => {
    if (!currentFile) return
    
    try {
      const response = await fetch('/api/execute-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          code: currentFile.content, 
          language: currentFile.language 
        })
      })
      const data = await response.json()
      
      setActiveTab('preview')
      console.log('Code execution result:', data)
    } catch (error) {
      console.error('Failed to execute code:', error)
    }
  }

  const handleAnalyzeCode = async () => {
    if (!currentFile) return
    
    try {
      const response = await fetch('/api/analyze-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          code: currentFile.content, 
          language: currentFile.language 
        })
      })
      const data = await response.json()
      console.log('Code analysis:', data)
    } catch (error) {
      console.error('Failed to analyze code:', error)
    }
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-50 w-64 transition-transform duration-300 border-r bg-muted/30 lg:z-auto`}>
        <div className="p-4 h-full flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              <span className="font-semibold hidden sm:block">AI Code Agent</span>
              <span className="font-semibold sm:hidden">AI Agent</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden"
            >
              ×
            </Button>
          </div>
          
          <Tabs defaultValue="files" className="w-full flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="files" className="text-xs">Files</TabsTrigger>
              <TabsTrigger value="templates" className="text-xs">Templates</TabsTrigger>
            </TabsList>
            <TabsContent value="files" className="mt-4 flex-1">
              <FileExplorer />
            </TabsContent>
            <TabsContent value="templates" className="mt-4 flex-1">
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start" size="sm">
                  <Code2 className="w-4 h-4 mr-2" />
                  React Component
                </Button>
                <Button variant="outline" className="w-full justify-start" size="sm">
                  <Settings className="w-4 h-4 mr-2" />
                  Node.js API
                </Button>
                <Button variant="outline" className="w-full justify-start" size="sm">
                  <Sparkles className="w-4 h-4 mr-2" />
                  TypeScript Module
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex items-center justify-between px-4 py-2">
            <div className="flex items-center gap-4">
              {!sidebarOpen && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSidebarOpen(true)}
                >
                  <FolderOpen className="w-4 h-4" />
                </Button>
              )}
              <div className="flex items-center gap-2 min-w-0">
                <Badge variant="secondary" className="text-xs">
                  {currentFile?.name || 'Untitled'}
                </Badge>
                {currentFile?.language && (
                  <Badge variant="outline" className="text-xs hidden sm:inline-flex">
                    {currentFile.language}
                  </Badge>
                )}
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleAnalyzeCode} className="hidden sm:flex">
                <Zap className="w-4 h-4 mr-2" />
                Analyze
              </Button>
              <Button variant="outline" size="sm" onClick={handleAnalyzeCode} className="sm:hidden px-2">
                <Zap className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" className="hidden sm:flex">
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>
              <Button variant="outline" size="sm" className="sm:hidden px-2">
                <Save className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleExecuteCode} className="hidden sm:flex">
                <Play className="w-4 h-4 mr-2" />
                Run
              </Button>
              <Button variant="outline" size="sm" onClick={handleExecuteCode} className="sm:hidden px-2">
                <Play className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" className="hidden sm:flex">
                <Settings className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" className="sm:hidden px-2">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </header>

        {/* Main Tabs */}
        <div className="flex-1 flex min-w-0">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col min-w-0">
            <TabsList className="grid w-full grid-cols-4 mx-4 mt-4 h-auto">
              <TabsTrigger value="editor" className="flex items-center gap-2 text-xs sm:text-sm py-2">
                <Code2 className="w-4 h-4" />
                <span className="hidden sm:inline">Editor</span>
                <span className="sm:hidden">Code</span>
              </TabsTrigger>
              <TabsTrigger value="chat" className="flex items-center gap-2 text-xs sm:text-sm py-2">
                <MessageSquare className="w-4 h-4" />
                <span className="hidden sm:inline">AI Assistant</span>
                <span className="sm:hidden">Chat</span>
              </TabsTrigger>
              <TabsTrigger value="openhands" className="flex items-center gap-2 text-xs sm:text-sm py-2">
                <Bot className="w-4 h-4" />
                <span className="hidden sm:inline">OpenHands</span>
                <span className="sm:hidden">Agent</span>
              </TabsTrigger>
              <TabsTrigger value="preview" className="flex items-center gap-2 text-xs sm:text-sm py-2">
                <Play className="w-4 h-4" />
                <span className="hidden sm:inline">Preview</span>
                <span className="sm:hidden">Run</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="editor" className="flex-1 m-2 sm:m-4 min-w-0">
              <Card className="h-full">
                <CardContent className="p-0 h-full">
                  <CodeEditor />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="chat" className="flex-1 m-2 sm:m-4 min-w-0">
              <Card className="h-full">
                <CardContent className="p-0 h-full">
                  <ChatInterface />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="openhands" className="flex-1 m-2 sm:m-4 min-w-0">
              <Card className="h-full">
                <CardContent className="p-0 h-full">
                  <OpenHandsPanel />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="preview" className="flex-1 m-2 sm:m-4 min-w-0">
              <Card className="h-full">
                <CardHeader>
                  <CardTitle className="text-lg">Code Preview & Output</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 sm:h-96 border rounded-lg flex items-center justify-center text-muted-foreground">
                    <div className="text-center px-4">
                      <Play className="w-8 h-8 sm:w-12 sm:h-12 mx-auto mb-4 opacity-50" />
                      <p className="text-sm sm:text-base">Run your code to see the output here</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}