import { create } from 'zustand'

interface CodeFile {
  id: string
  name: string
  content: string
  language: string
  createdAt: Date
  updatedAt: Date
}

interface CodeStore {
  files: CodeFile[]
  currentFile: CodeFile | null
  createFile: (name: string, content?: string, language?: string) => void
  updateFile: (id: string, content: string) => void
  deleteFile: (id: string) => void
  setCurrentFile: (file: CodeFile | null) => void
  renameFile: (id: string, newName: string) => void
}

export const useCodeStore = create<CodeStore>((set, get) => ({
  files: [
    {
      id: '1',
      name: 'index.js',
      content: '// Welcome to AI Coding Agent\n// Start coding here or ask the AI assistant for help\n\nconsole.log("Hello, World!");',
      language: 'javascript',
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ],
  currentFile: null,
  
  createFile: (name: string, content = '', language = 'javascript') => {
    const newFile: CodeFile = {
      id: Date.now().toString(),
      name,
      content,
      language,
      createdAt: new Date(),
      updatedAt: new Date()
    }
    
    set((state) => ({
      files: [...state.files, newFile],
      currentFile: newFile
    }))
  },
  
  updateFile: (id: string, content: string) => {
    set((state) => ({
      files: state.files.map((file) =>
        file.id === id
          ? { ...file, content, updatedAt: new Date() }
          : file
      ),
      currentFile: state.currentFile?.id === id
        ? { ...state.currentFile, content, updatedAt: new Date() }
        : state.currentFile
    }))
  },
  
  deleteFile: (id: string) => {
    set((state) => {
      const newFiles = state.files.filter((file) => file.id !== id)
      return {
        files: newFiles,
        currentFile: state.currentFile?.id === id ? newFiles[0] || null : state.currentFile
      }
    })
  },
  
  setCurrentFile: (file: CodeFile | null) => {
    set({ currentFile: file })
  },
  
  renameFile: (id: string, newName: string) => {
    set((state) => ({
      files: state.files.map((file) =>
        file.id === id ? { ...file, name: newName, updatedAt: new Date() } : file
      ),
      currentFile: state.currentFile?.id === id
        ? { ...state.currentFile, name: newName, updatedAt: new Date() }
        : state.currentFile
    }))
  }
}))

// Initialize with the first file as current
useCodeStore.setState((state) => ({
  currentFile: state.files[0] || null
}))