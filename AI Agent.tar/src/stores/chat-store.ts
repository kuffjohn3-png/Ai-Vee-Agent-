import { create } from 'zustand'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

interface ChatStore {
  messages: Message[]
  isLoading: boolean
  sendMessage: (content: string) => Promise<void>
  clearMessages: () => void
  setLoading: (loading: boolean) => void
}

export const useChatStore = create<ChatStore>((set, get) => ({
  messages: [
    {
      id: '1',
      role: 'assistant',
      content: 'Hello! I\'m your AI coding assistant. I can help you write code, debug issues, explain concepts, and much more. What would you like to work on today?',
      timestamp: new Date()
    }
  ],
  isLoading: false,
  
  sendMessage: async (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date()
    }
    
    set((state) => ({
      messages: [...state.messages, userMessage],
      isLoading: true
    }))
    
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: content })
      })
      
      const data = await response.json()
      
      if (data.response) {
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: data.response,
          timestamp: new Date()
        }
        
        set((state) => ({
          messages: [...state.messages, assistantMessage],
          isLoading: false
        }))
      }
    } catch (error) {
      console.error('Failed to send message:', error)
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Sorry, I encountered an error while processing your request. Please try again.',
        timestamp: new Date()
      }
      
      set((state) => ({
        messages: [...state.messages, errorMessage],
        isLoading: false
      }))
    }
  },
  
  clearMessages: () => {
    set({
      messages: [
        {
          id: '1',
          role: 'assistant',
          content: 'Hello! I\'m your AI coding assistant. I can help you write code, debug issues, explain concepts, and much more. What would you like to work on today?',
          timestamp: new Date()
        }
      ]
    })
  },
  
  setLoading: (loading: boolean) => {
    set({ isLoading: loading })
  }
}))