import { create } from 'zustand'
import { OpenHandsAgent, OpenHandsTask, OpenHandsConfig } from '@/lib/openhands/types'
import { openHandsManager } from '@/lib/openhands/manager'

interface OpenHandsStore {
  // Agent state
  agents: OpenHandsAgent[]
  currentAgent: OpenHandsAgent | null
  
  // Task state
  tasks: OpenHandsTask[]
  currentTask: OpenHandsTask | null
  isExecutingTask: boolean
  
  // Configuration
  config: OpenHandsConfig
  
  // Actions
  refreshAgents: () => void
  setCurrentAgent: (agent: OpenHandsAgent | null) => void
  executeTask: (task: Omit<OpenHandsTask, 'id' | 'status' | 'createdAt' | 'completedAt'>) => Promise<OpenHandsTask>
  refreshTasks: () => void
  setCurrentTask: (task: OpenHandsTask | null) => void
  clearTasks: () => void
  updateConfig: (config: Partial<OpenHandsConfig>) => void
}

export const useOpenHandsStore = create<OpenHandsStore>((set, get) => ({
  // Initial state
  agents: openHandsManager.getAllAgents(),
  currentAgent: openHandsManager.getAgent('primary') || null,
  tasks: [],
  currentTask: null,
  isExecutingTask: false,
  config: openHandsManager.getConfig(),

  // Actions
  refreshAgents: () => {
    const agents = openHandsManager.getAllAgents()
    set({ agents, currentAgent: agents[0] || null })
  },

  setCurrentAgent: (agent) => {
    set({ currentAgent: agent })
  },

  executeTask: async (taskData) => {
    set({ isExecutingTask: true })
    
    try {
      const task = await openHandsManager.executeTask(taskData)
      
      set(state => ({
        tasks: [task, ...state.tasks],
        currentTask: task,
        isExecutingTask: false
      }))
      
      return task
    } catch (error) {
      set({ isExecutingTask: false })
      throw error
    }
  },

  refreshTasks: () => {
    const tasks = openHandsManager.getAllTasks()
    set({ tasks })
  },

  setCurrentTask: (task) => {
    set({ currentTask: task })
  },

  clearTasks: () => {
    openHandsManager.clearTasks()
    set({ tasks: [], currentTask: null })
  },

  updateConfig: (newConfig) => {
    openHandsManager.updateConfig(newConfig)
    set({ config: openHandsManager.getConfig() })
  }
}))