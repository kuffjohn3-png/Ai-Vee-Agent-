export interface OpenHandsAgent {
  id: string
  name: string
  capabilities: string[]
  status: 'idle' | 'thinking' | 'executing' | 'error'
  environment?: 'sandbox' | 'local'
}

export interface OpenHandsTask {
  id: string
  type: 'code_generation' | 'code_analysis' | 'code_execution' | 'debugging' | 'refactoring'
  prompt: string
  code?: string
  language?: string
  status: 'pending' | 'running' | 'completed' | 'failed'
  result?: any
  error?: string
  createdAt: Date
  completedAt?: Date
}

export interface OpenHandsConfig {
  sandbox: {
    enabled: boolean
    timeout: number
    memory: string
    cpu: string
  }
  agent: {
    model: string
    temperature: number
    maxTokens: number
  }
  features: {
    codeExecution: boolean
    fileSystem: boolean
    terminal: boolean
    webAccess: boolean
  }
}

export const defaultOpenHandsConfig: OpenHandsConfig = {
  sandbox: {
    enabled: true,
    timeout: 30000,
    memory: '512MB',
    cpu: '1'
  },
  agent: {
    model: 'gpt-4',
    temperature: 0.7,
    maxTokens: 4000
  },
  features: {
    codeExecution: true,
    fileSystem: true,
    terminal: true,
    webAccess: false
  }
}