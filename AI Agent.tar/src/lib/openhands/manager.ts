import { OpenHandsAgent, OpenHandsTask, OpenHandsConfig } from './types'
import { defaultOpenHandsConfig } from './types'

class OpenHandsManager {
  private config: OpenHandsConfig
  private agents: Map<string, OpenHandsAgent> = new Map()
  private tasks: Map<string, OpenHandsTask> = new Map()

  constructor(config: Partial<OpenHandsConfig> = {}) {
    this.config = { ...defaultOpenHandsConfig, ...config }
    this.initializeDefaultAgent()
  }

  private initializeDefaultAgent() {
    const defaultAgent: OpenHandsAgent = {
      id: 'primary',
      name: 'AI Coding Assistant',
      capabilities: [
        'code_generation',
        'code_analysis', 
        'code_execution',
        'debugging',
        'refactoring',
        'file_operations'
      ],
      status: 'idle',
      environment: this.config.sandbox.enabled ? 'sandbox' : 'local'
    }
    
    this.agents.set(defaultAgent.id, defaultAgent)
  }

  getAgent(id: string = 'primary'): OpenHandsAgent | undefined {
    return this.agents.get(id)
  }

  getAllAgents(): OpenHandsAgent[] {
    return Array.from(this.agents.values())
  }

  updateAgentStatus(id: string, status: OpenHandsAgent['status']): void {
    const agent = this.agents.get(id)
    if (agent) {
      agent.status = status
      this.agents.set(id, agent)
    }
  }

  async executeTask(task: Omit<OpenHandsTask, 'id' | 'status' | 'createdAt' | 'completedAt'>): Promise<OpenHandsTask> {
    const fullTask: OpenHandsTask = {
      ...task,
      id: `task_${Date.now()}`,
      status: 'pending',
      createdAt: new Date()
    }

    this.tasks.set(fullTask.id, fullTask)
    
    try {
      fullTask.status = 'running'
      this.updateAgentStatus('primary', 'executing')
      
      const result = await this.processTask(fullTask)
      
      fullTask.result = result
      fullTask.status = 'completed'
      fullTask.completedAt = new Date()
      
    } catch (error) {
      fullTask.error = error instanceof Error ? error.message : 'Unknown error'
      fullTask.status = 'failed'
      fullTask.completedAt = new Date()
    } finally {
      this.updateAgentStatus('primary', 'idle')
    }

    this.tasks.set(fullTask.id, fullTask)
    return fullTask
  }

  private async processTask(task: OpenHandsTask): Promise<any> {
    switch (task.type) {
      case 'code_execution':
        return this.executeCode(task.code!, task.language!)
      
      case 'code_generation':
        return this.generateCode(task.prompt, task.language)
      
      case 'code_analysis':
        return this.analyzeCode(task.code!, task.language)
      
      case 'debugging':
        return this.debugCode(task.code!, task.prompt)
      
      case 'refactoring':
        return this.refactorCode(task.code!, task.prompt)
      
      default:
        throw new Error(`Unknown task type: ${task.type}`)
    }
  }

  private async executeCode(code: string, language: string): Promise<any> {
    const response = await fetch('/api/openhands/execute-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, language, sandbox: true })
    })
    
    if (!response.ok) {
      throw new Error('OpenHands code execution failed')
    }
    
    return response.json()
  }

  private async generateCode(prompt: string, language?: string): Promise<any> {
    const response = await fetch('/api/generate-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, language: language || 'javascript' })
    })
    
    if (!response.ok) {
      throw new Error('Code generation failed')
    }
    
    return response.json()
  }

  private async analyzeCode(code: string, language?: string): Promise<any> {
    const response = await fetch('/api/analyze-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, language: language || 'javascript' })
    })
    
    if (!response.ok) {
      throw new Error('Code analysis failed')
    }
    
    return response.json()
  }

  private async debugCode(code: string, issue: string): Promise<any> {
    const response = await fetch('/api/debug-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, issue })
    })
    
    if (!response.ok) {
      throw new Error('Code debugging failed')
    }
    
    return response.json()
  }

  private async refactorCode(code: string, instructions: string): Promise<any> {
    const response = await fetch('/api/refactor-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, instructions })
    })
    
    if (!response.ok) {
      throw new Error('Code refactoring failed')
    }
    
    return response.json()
  }

  getTask(id: string): OpenHandsTask | undefined {
    return this.tasks.get(id)
  }

  getAllTasks(): OpenHandsTask[] {
    return Array.from(this.tasks.values()).sort((a, b) => 
      b.createdAt.getTime() - a.createdAt.getTime()
    )
  }

  getTasksByType(type: OpenHandsTask['type']): OpenHandsTask[] {
    return this.getAllTasks().filter(task => task.type === type)
  }

  clearTasks(): void {
    this.tasks.clear()
  }

  updateConfig(newConfig: Partial<OpenHandsConfig>): void {
    this.config = { ...this.config, ...newConfig }
  }

  getConfig(): OpenHandsConfig {
    return { ...this.config }
  }
}

// Singleton instance
export const openHandsManager = new OpenHandsManager()

export default OpenHandsManager