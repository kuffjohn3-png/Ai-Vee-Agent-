export interface CodeTemplate {
  id: string
  name: string
  description: string
  language: string
  category: string
  content: string
}

export const codeTemplates: CodeTemplate[] = [
  {
    id: 'react-component',
    name: 'React Component',
    description: 'Basic functional React component with hooks',
    language: 'javascript',
    category: 'React',
    content: `import React, { useState, useEffect } from 'react'

export default function ComponentName() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    // Component lifecycle logic here
  }, [])

  const handleClick = () => {
    // Event handler logic here
  }

  return (
    <div className="component">
      <h1>Component Title</h1>
      <p>Component description</p>
      <button onClick={handleClick}>
        Click me
      </button>
    </div>
  )
}`
  },
  {
    id: 'express-server',
    name: 'Express Server',
    description: 'Basic Express.js server setup',
    language: 'javascript',
    category: 'Node.js',
    content: `const express = require('express')
const cors = require('cors')
const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json())

// Routes
app.get('/', (req, res) => {
  res.json({ message: 'Hello World!' })
})

app.get('/api/users', (req, res) => {
  // Get users logic
  res.json([])
})

app.post('/api/users', (req, res) => {
  // Create user logic
  res.json({ success: true })
})

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({ error: 'Something went wrong!' })
})

app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`)
})`
  },
  {
    id: 'python-flask',
    name: 'Flask API',
    description: 'Basic Flask REST API',
    language: 'python',
    category: 'Python',
    content: `from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return jsonify({"message": "Hello World!"})

@app.route('/api/users', methods=['GET'])
def get_users():
    # Get users logic
    return jsonify([])

@app.route('/api/users', methods=['POST'])
def create_user():
    # Create user logic
    return jsonify({"success": True})

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({"error": "Internal server error"}), 500

if __name__ == '__main__':
    app.run(debug=True)`
  },
  {
    id: 'typescript-class',
    name: 'TypeScript Class',
    description: 'TypeScript class with properties and methods',
    language: 'typescript',
    category: 'TypeScript',
    content: `interface User {
  id: number
  name: string
  email: string
}

class UserService {
  private users: User[] = []

  constructor() {
    this.initializeUsers()
  }

  private initializeUsers(): void {
    // Initialize with default users
  }

  public getAllUsers(): User[] {
    return this.users
  }

  public getUserById(id: number): User | undefined {
    return this.users.find(user => user.id === id)
  }

  public createUser(userData: Omit<User, 'id'>): User {
    const newUser: User = {
      id: this.users.length + 1,
      ...userData
    }
    this.users.push(newUser)
    return newUser
  }

  public updateUser(id: number, updates: Partial<User>): User | null {
    const userIndex = this.users.findIndex(user => user.id === id)
    if (userIndex === -1) return null

    this.users[userIndex] = { ...this.users[userIndex], ...updates }
    return this.users[userIndex]
  }

  public deleteUser(id: number): boolean {
    const userIndex = this.users.findIndex(user => user.id === id)
    if (userIndex === -1) return false

    this.users.splice(userIndex, 1)
    return true
  }
}

export default UserService`
  },
  {
    id: 'html-template',
    name: 'HTML5 Template',
    description: 'Modern HTML5 page template',
    language: 'html',
    category: 'HTML',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Page description">
    <title>Page Title</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="home">
            <h1>Welcome</h1>
            <p>This is the main content area.</p>
        </section>

        <section id="about">
            <h2>About Us</h2>
            <p>Information about your project or company.</p>
        </section>

        <section id="contact">
            <h2>Contact</h2>
            <form>
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
                
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
                
                <label for="message">Message:</label>
                <textarea id="message" name="message" required></textarea>
                
                <button type="submit">Send</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Your Company. All rights reserved.</p>
    </footer>

    <script src="script.js"></script>
</body>
</html>`
  },
  {
    id: 'css-reset',
    name: 'CSS Reset',
    description: 'Modern CSS reset with utility classes',
    language: 'css',
    category: 'CSS',
    content: `/* CSS Reset */
*,
*::before,
*::after {
  box-sizing: border-box;
}

* {
  margin: 0;
  padding: 0;
}

html,
body {
  height: 100%;
}

body {
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
}

img,
picture,
video,
canvas,
svg {
  display: block;
  max-width: 100%;
}

input,
button,
textarea,
select {
  font: inherit;
}

p,
h1,
h2,
h3,
h4,
h5,
h6 {
  overflow-wrap: break-word;
}

#root,
#__next {
  isolation: isolate;
}

/* Utility Classes */
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
}

.flex {
  display: flex;
}

.flex-col {
  flex-direction: column;
}

.items-center {
  align-items: center;
}

.justify-center {
  justify-content: center;
}

.text-center {
  text-align: center;
}

.mb-4 {
  margin-bottom: 1rem;
}

.p-4 {
  padding: 1rem;
}

.rounded {
  border-radius: 0.25rem;
}

.shadow {
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
}`
  }
]

export const getTemplatesByCategory = (category: string): CodeTemplate[] => {
  return codeTemplates.filter(template => template.category === category)
}

export const getTemplateById = (id: string): CodeTemplate | undefined => {
  return codeTemplates.find(template => template.id === id)
}

export const getCategories = (): string[] => {
  return [...new Set(codeTemplates.map(template => template.category))]
}